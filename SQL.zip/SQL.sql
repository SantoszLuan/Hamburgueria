﻿Create table usuarios (
ID Int UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
Nome Varchar (100),
Telefone Varchar (20),
Email Varchar(50),
Senha Varchar(10),
Primary Key (ID)) ENGINE = MyISAM;